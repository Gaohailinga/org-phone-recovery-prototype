# 原型部署指南

## 方案 A：GitHub Pages（推荐，永久免费）

适用场景：需要长期公开的访问链接。

### 前置条件
- GitHub 账号
- 用户有一台能打开 github.com 的设备（手机/电脑均可）
- 当前环境有 `curl` 和 `git`

---

## GitHub Device Flow 授权码方式（推荐首选）

此方式无需用户手动生成 Token，通过 github.com/device 页面输入授权码即可完成授权。

### 步骤 1：发起设备授权请求

```bash
CLIENT_ID="178c6fc778ccc68e1d6a"

curl -s -X POST https://github.com/login/device/code \
  -H "Accept: application/json" \
  -d "client_id=$CLIENT_ID" \
  -d "scope=repo,workflow" | tee /tmp/github_device.json
```

返回示例：

```json
{
  "device_code": "xxxxx",
  "user_code": "ABCD-1234",
  "verification_uri": "https://github.com/login/device",
  "interval": 5
}
```

### 步骤 2：引导用户在手机上完成授权

让用户在手机浏览器打开：

```
https://github.com/login/device
```

输入步骤 1 返回的 `user_code`（如 `ABCD-1234`），点击 **Continue** → **Authorize**。

用户确认后告知 AI 继续。

### 步骤 3：轮询获取 Access Token

用户授权后，轮询 GitHub API 兑换 access_token：

```bash
DEVICE_CODE=$(grep -o '"device_code":"[^"]*' /tmp/github_device.json | cut -d'"' -f4)
CLIENT_ID="178c6fc778ccc68e1d6a"

for i in $(seq 1 20); do
  RESPONSE=$(curl -s -X POST https://github.com/login/oauth/access_token \
    -H "Accept: application/json" \
    -d "client_id=$CLIENT_ID" \
    -d "device_code=$DEVICE_CODE" \
    -d "grant_type=urn:ietf:params:oauth:grant-type:device_code")

  ACCESS_TOKEN=$(echo "$RESPONSE" | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)
  if [ -n "$ACCESS_TOKEN" ]; then
    echo "$RESPONSE" > /tmp/github_token.json
    break
  fi
  sleep 5
done
```

> **安全提示**：access_token 全程不展示给用户，用完后通过步骤 8 删除临时文件。

### 步骤 4：创建 GitHub 仓库

向用户确认 GitHub 用户名和期望的仓库名，然后创建公开仓库：

```bash
GITHUB_USER="用户GitHub用户名"
REPO_NAME="仓库名"
TOKEN=$(grep -o '"access_token":"[^"]*' /tmp/github_token.json | cut -d'"' -f4)

curl -s -X POST https://api.github.com/user/repos \
  -H "Authorization: token $TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  -d "{\"name\":\"$REPO_NAME\",\"description\":\"原型项目\",\"private\":false,\"auto_init\":true}"
```

> 如仓库已存在，跳过此步骤。

### 步骤 5：推送原型代码

```bash
PROTOTYPE_DIR="/path/to/prototype"
TOKEN=$(grep -o '"access_token":"[^"]*' /tmp/github_token.json | cut -d'"' -f4)

cd "$PROTOTYPE_DIR"

# 初始化 git（如已初始化则跳过）
git init 2>/dev/null || true
git config user.email "deploy@prototype.local"
git config user.name "Deploy Bot"

# 配置远程仓库（带 token 认证）
git remote remove origin 2>/dev/null || true
git remote add origin "https://$GITHUB_USER:$TOKEN@github.com/$GITHUB_USER/$REPO_NAME.git"

# 拉取远程更新，合并本地代码
git pull origin main --rebase 2>/dev/null || true

# 提交并推送
git add .
git commit -m "feat: 原型部署" || true
git push origin main
```

### 步骤 6：开启 GitHub Pages

```bash
TOKEN=$(grep -o '"access_token":"[^"]*' /tmp/github_token.json | cut -d'"' -f4)

curl -s -X POST "https://api.github.com/repos/$GITHUB_USER/$REPO_NAME/pages" \
  -H "Authorization: token $TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  -d '{"source":{"branch":"main","path":"/"}}'
```

> 如 Pages 已开启，此接口会返回错误，忽略即可。

### 步骤 7：等待部署并验证

GitHub Pages 首次部署需要 1-3 分钟。轮询验证：

```bash
echo "等待部署完成（最多 2 分钟）..."
for i in $(seq 1 12); do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" "https://$GITHUB_USER.github.io/$REPO_NAME/")
  if [ "$CODE" = "200" ]; then
    echo "部署成功！"
    break
  fi
  echo "  等待中... ($CODE)"
  sleep 10
done
```

### 步骤 8：清理临时文件

```bash
rm -f /tmp/github_token.json /tmp/github_device.json
```

> **关键**：access_token 是敏感信息，务必在部署完成后立即清理。

### 最终链接

```
https://username.github.io/repo-name/                    （评审版-方案一）
https://username.github.io/repo-name/v2.html              （评审版-方案二）
https://username.github.io/repo-name/index-original.html  （纯净版-方案一）
https://username.github.io/repo-name/v2-original.html     （纯净版-方案二）
```

---

## 备选：SSH 方式部署

如果 GitHub API（`github.com`）在当前环境不可达，但 SSH（`github.com:22`）可达：

### 步骤 1：生成 SSH 密钥

```bash
ssh-keygen -t ed25519 -C "deploy@prototype" -f ~/.ssh/id_ed25519_github -N ""
cat ~/.ssh/id_ed25519_github.pub
```

### 步骤 2：用户添加公钥到 GitHub

引导用户在 [github.com/settings/keys](https://github.com/settings/keys) 添加公钥。

### 步骤 3：SSH 推送

```bash
ssh-keyscan github.com >> ~/.ssh/known_hosts 2>/dev/null
git remote set-url origin git@github.com:$GITHUB_USER/$REPO_NAME.git
GIT_SSH_COMMAND="ssh -i ~/.ssh/id_ed25519_github -o IdentitiesOnly=yes" git push origin main
```

### 步骤 4：手动开启 Pages

SSH 无法调用 API，需用户手动在 [github.com/.../settings/pages](https://github.com) 中选择 `main` 分支、`/ (root)` 并保存。

---

## 方案 B：EdgeOne Pages

适用场景：腾讯云服务生态内，短期分享。

### 特点
- 系统分配域名带 token 保护
- 临时链接可能几小时到几天后失效
- 如需永久公开，仍需绑定自定义域名

### 最终链接
```
https://xxx.edgeone.cool/?eo_token=xxx&eo_time=xxx
```

---

## 方案 C：打包发送

适用场景：用户无域名、无平台账号，且不需要线上访问。

```bash
cd /path/to/prototype
zip -r prototype.zip index.html v2.html css js
```

对方解压后双击 HTML 即可在浏览器打开。

---

## 常见问题

| 问题 | 原因 | 解决 |
|------|------|------|
| device code 请求超时 | 网络无法直连 `github.com` | 改用 SSH 方式 |
| token 轮询返回 `authorization_pending` | 用户还没点授权 | 继续等待，每 5 秒重试 |
| push 被拒绝（non-fast-forward） | 远程有新 commit | 先 `git pull --rebase` |
| Pages 返回 404 | 还没部署完成 | 再等 1-2 分钟 |
| token 轮询返回 `expired_token` | 授权码过期（15 分钟） | 重新执行步骤 1-2 |
