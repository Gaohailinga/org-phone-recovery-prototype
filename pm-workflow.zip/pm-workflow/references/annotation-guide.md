# 评审标注版原型实现指南

> 在纯净原型基础上叠加评审指引层，生成双版共存的交付物。纯净版交付开发，评审版用于团队评审/培训。

## 标注目的

评审标注版通过可视化指引标注页面关键逻辑，帮助非技术干系人（业务方、评审人、新人）理解交互流程。标注始终可拖拽移动，不遮挡卡片按钮。

## 标注元素结构

```html
<!-- 标注层容器，置于每个 page-wrapper 外层，不嵌套在卡片内 -->
<div class="annot-layer">
  <!-- 指引气泡：白色气泡 + 箭头，用于步骤说明、关键提示 -->
  <div class="annot annot-right" style="top: 20px; left: 390px;" data-annot-id="step-1">
    <span class="annot-label">步骤说明</span><br>
    关键描述<strong class="annot-key">重点词</strong>
  </div>

  <!-- 暗色遮罩标注：灰色半透明区块，用于区域标注 -->
  <div class="annot annot-dim" style="top: 10px; left: 10px; width: 200px; height: 80px;" data-annot-id="dim-1">
    非重点区域说明
  </div>

  <!-- 高亮框：彩色边框 + 背景，用于重点区域强调 -->
  <div class="annot annot-highlight" style="top: 10px; left: 10px; width: 200px; height: 80px;" data-annot-id="hl-1">
    重点区域说明
  </div>
</div>
```

## 标注类型详解

| 类型 | CSS 类 | 视觉样式 | 适用场景 |
|------|--------|---------|---------|
| 指引气泡 | `.annot` | 白色背景 + 橙色虚线边框 + 箭头 | 步骤说明、关键提示、交互指引 |
| 暗色标注 | `.annot-dim` | 灰色半透明区块 | 非重点区域标识、功能说明 |
| 高亮框 | `.annot-highlight` | 橙色边框 + 淡背景 + 脉冲动画 | 重点区域强调、关键字段标识 |
| 顶部气泡 | `.annot-top` | 箭头在下方，指向卡片顶部 | 顶部元素指引 |
| 右侧气泡 | `.annot-right` | 箭头在左侧，指向卡片 | **推荐**：避免遮挡按钮 |
| 左侧气泡 | `.annot-left` | 箭头在右侧 | 卡片右侧无空间时使用 |
| 底部气泡 | `.annot-bottom` | 箭头在上方 | 底部元素指引 |

### 标注文案规范

```html
<!-- 步骤指引格式 -->
<span class="annot-label">步骤一</span><br>
请选择一种<strong class="annot-key">验证方式</strong>进行身份核实

<!-- 信息提示格式 -->
<strong class="annot-key">重要：</strong>机构手机号找回需先验证身份，请确保信息与登记数据一致

<!-- 字段说明格式 -->
<span class="annot-label">字段说明</span><br>
请输入<strong class="annot-key">18 位</strong>统一社会信用代码
```

## CSS 关键规则

### 标注层容器

```css
.annot-layer {
  position: absolute;
  top: 32px;
  left: 28px;
  width: 344px;
  pointer-events: none;    /* 默认不拦截事件 */
  z-index: auto;            /* 不参与层级竞争 */
  overflow: visible;
}
```

### 标注气泡

```css
.annot {
  position: absolute;
  background: #fffef5;
  border: 1.5px dashed #ff8c42;
  border-radius: 6px;
  padding: 8px 10px;
  font-size: 11px;
  color: #6b4200;
  line-height: 1.5;
  box-shadow: 0 2px 8px rgba(255, 140, 66, 0.15);
  pointer-events: auto;     /* 恢复自身可交互（拖拽） */
  cursor: grab;
  user-select: none;
}

/* 标注标签（步骤编号） */
.annot .annot-label {
  display: inline-block;
  background: #ff6b2b;
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 3px;
  margin-bottom: 4px;
}

/* 关键词高亮 */
.annot .annot-key {
  color: #d45d00;
  font-weight: 700;
}
```

### 标注箭头

```css
/* 气泡在右侧，箭头在左指向卡片 — 推荐默认使用 */
.annot-right::after {
  left: -8px;
  top: 18px;
  border-width: 6px 8px 6px 0;
  border-color: transparent #ff8c42 transparent transparent;
}

/* 气泡在上方，箭头在下指向卡片 */
.annot-top::after {
  bottom: -8px;
  left: 24px;
  border-width: 8px 6px 0 6px;
  border-color: #ff8c42 transparent transparent transparent;
}
```

### 高亮框

```css
.annot-highlight {
  position: absolute;
  border: 2px solid #ff6b2b;
  border-radius: 4px;
  background: rgba(255, 107, 43, 0.04);
  z-index: 49;
  animation: highlightPulse 2s ease-in-out infinite;
}

@keyframes highlightPulse {
  0%, 100% { border-color: #ff6b2b; box-shadow: 0 0 0 2px rgba(255,107,43,0.1); }
  50% { border-color: #ffaa66; box-shadow: 0 0 0 4px rgba(255,107,43,0.06); }
}
```

### 暗色遮罩

```css
.annot-dim {
  position: absolute;
  background: rgba(0, 0, 0, 0.06);
  border-radius: 4px;
  z-index: 48;
}
```

### z-index 层级关系

```
z-index: 100   → .annot.dragging（拖拽中的标注，临时提升）
z-index: 51    → .card / .step-card（卡片，始终可点击）
z-index: 49    → .annot-highlight（高亮框，在卡片下方）
z-index: 48    → .annot-dim（暗色遮罩，在最下层）
z-index: auto  → .annot-layer（标注容器，不参与层级）
```

**核心原则**：标注层不抢占卡片层级，卡片按钮始终可点。标注应放在卡片外侧（`left ≥ 385px`）。

### 拖拽状态

```css
/* 标注悬停提示 */
.annot:hover,
.annot-dim:hover,
.annot-highlight:hover {
  box-shadow: 0 0 0 4px rgba(255, 107, 43, 0.25);
}

/* 拖拽中：提升 z-index 临时高于卡片 */
.annot.dragging,
.annot-dim.dragging,
.annot-highlight.dragging {
  cursor: grabbing;
  opacity: 0.92;
  z-index: 100;
  transition: none;
}
```

## 标注拖拽模块

使用 `assets/annot-drag.js`，复制到项目 `js/` 目录，在 HTML 中引用：

```html
<script src="js/annot-drag.js"></script>
```

### 功能清单

| 功能 | 说明 |
|------|------|
| 拖拽移动 | 所有 `.annot`、`.annot-dim`、`.annot-highlight` 可鼠标/触摸拖拽 |
| 位置持久化 | 松开后自动保存到 `localStorage`（key: `annot_positions_v3`） |
| 位置恢复 | 页面刷新后自动恢复到上次拖拽位置 |
| 双击重置 | 双击任意标注重置该标注到默认位置 |
| 全局重置 | 右下角「↺ 重置标注」按钮，一键重置所有标注 |
| 拖拽手柄 | 每个标注右上角显示 `⋮` 手柄，悬停高亮 |
| Toast 提示 | 重置操作后显示轻提示 "已重置位置" |

### 拖拽引擎原理

```
mousedown/touchstart → 记录起始位置，标注添加 .dragging
mousemove/touchmove  → 实时计算偏移，更新 top/left
mouseup/touchend     → 移除 .dragging，保存到 localStorage
dblclick             → 重置该标注到默认位置
```

### localStorage 数据结构

```json
{
  "page1__0": { "top": "120px", "left": "420px" },
  "page1__1": { "top": "78px", "left": "405px" },
  "page2__0": { "top": "45px", "left": "390px" }
}
```

Key 格式：`{page-wrapper-id}__{标注在层内的索引}`

## 双版分离策略

### 生成流程

```
纯净原型 → 叠加标注层 → 提交 git（评审版）
                       ↓
              git checkout 初始提交 → 提取原始文件 → *-original.*
```

### 文件结构

```
workspace/
├── index.html              # 评审标注版（双验证）
├── v2.html                 # 评审标注版（单验证）
├── index-original.html     # 纯净版（双验证）
├── v2-original.html        # 纯净版（单验证）
├── css/
│   ├── style.css           # 评审版样式（含标注样式）
│   └── style-original.css  # 纯净版样式（无标注）
└── js/
    ├── app.js              # 双验证交互逻辑
    ├── app-v2.js           # 单验证交互逻辑
    ├── annot-drag.js       # 标注拖拽模块
    ├── app-original.js     # 纯净版双验证逻辑
    └── app-v2-original.js  # 纯净版单验证逻辑
```

### 提取纯净版的方法

```bash
# 从 git 初始提交提取原始 HTML/CSS/JS
git show <initial-commit>:index.html > index-original.html
git show <initial-commit>:css/style.css > css/style-original.css
git show <initial-commit>:js/app.js > js/app-original.js

# 更新 HTML 中的引用路径（指向独立文件）
# <link rel="stylesheet" href="css/style-original.css">
# <script src="js/app-original.js"></script>
```

## 部署

### GitHub Pages 链接结构

| 版本 | URL 路径 | 说明 |
|------|---------|------|
| 评审版-方案一 | `/index.html` | 含标注，二选一验证 |
| 评审版-方案二 | `/v2.html` | 含标注，单验证入口 |
| 纯净版-方案一 | `/index-original.html` | 无标注，交付开发 |
| 纯净版-方案二 | `/v2-original.html` | 无标注，交付开发 |

部署后，在 PRD 中整理所有访问链接。

## 常见问题与修复

| 问题 | 原因 | 修复方案 |
|------|------|---------|
| 标注遮挡按钮无法点击 | 标注层 `z-index` 压在卡片之上 | 卡片设置 `z-index: 51`，标注移到卡片外侧（`left ≥ 385px`） |
| 验证方式全部选中而非二选一 | 卡片 `<div>` 缺少 `data-method` 属性 | 为每个选项卡片添加 `data-method="legal"` / `data-method="bank"` |
| 拖拽标注时误触发按钮点击 | `mousedown` 事件冒泡到按钮 | 拖拽时标注临时提升 `z-index: 100`；标注始终放在卡片外 |
| 刷新后标注位置丢失 | 未实现 localStorage 持久化 | 使用 `annot-drag.js` 自动保存/恢复位置 |
| 标注样式污染纯净版 | 纯净版共用评审版 CSS | 生成独立 `style-original.css`，剥离标注样式 |
| 标注在移动端太小看不清 | 字体固定 `11px` | 可添加 `@media` 适配，或引导用户拖拽到可视位置 |
