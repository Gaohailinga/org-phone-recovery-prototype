/* ============================================================
   通用工具函数
============================================================ */
function $(id) {
  return document.getElementById(id);
}

function showToast(message, duration = 2000) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, duration);
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach((el) => el.classList.add('hidden'));
  $(pageId).classList.remove('hidden');
}

function validatePhone(phone) {
  return /^1[3-9]\d{9}$/.test(phone);
}

function startCountdown(btn, seconds = 60) {
  btn.disabled = true;
  let remaining = seconds;
  const originalText = btn.textContent;
  btn.textContent = `${remaining}s`;
  const timer = setInterval(() => {
    remaining -= 1;
    if (remaining <= 0) {
      clearInterval(timer);
      btn.disabled = false;
      btn.textContent = originalText;
    } else {
      btn.textContent = `${remaining}s`;
    }
  }, 1000);
}

/* ============================================================
   页面交互
============================================================ */
$('btn-start').addEventListener('click', () => {
  const value = $('example').value.trim();
  if (!value) {
    showToast('请输入示例字段');
    return;
  }
  showPage('page-success');
});

$('success-done').addEventListener('click', () => {
  showPage('page-home');
  showToast('已返回首页');
});
