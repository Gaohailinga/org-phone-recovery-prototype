#!/bin/bash
set -e

# 部署原型到 GitHub Pages
# 用法：./deploy-github-pages.sh <本地原型目录> <GitHub用户名> <仓库名>

PROTOTYPE_DIR="${1:-.}"
GITHUB_USER="${2:-}"
REPO_NAME="${3:-}"

if [ -z "$GITHUB_USER" ] || [ -z "$REPO_NAME" ]; then
  echo "Usage: $0 <prototype-dir> <github-user> <repo-name>"
  exit 1
fi

CLIENT_ID="178c6fc778ccc68e1d6a"

echo "Step 1: 发起 GitHub device flow 授权..."
DEVICE_RESPONSE=$(curl -s -X POST https://github.com/login/device/code \
  -H "Accept: application/json" \
  -d "client_id=$CLIENT_ID" \
  -d "scope=repo")

DEVICE_CODE=$(echo "$DEVICE_RESPONSE" | grep -o '"device_code":"[^"]*' | cut -d'"' -f4)
USER_CODE=$(echo "$DEVICE_RESPONSE" | grep -o '"user_code":"[^"]*' | cut -d'"' -f4)

echo "请在浏览器打开 https://github.com/login/device"
echo "输入授权码: $USER_CODE"
echo "完成后按回车继续..."
read -r

echo "Step 2: 获取访问令牌..."
for i in $(seq 1 20); do
  TOKEN_RESPONSE=$(curl -s -X POST https://github.com/login/oauth/access_token \
    -H "Accept: application/json" \
    -d "client_id=$CLIENT_ID" \
    -d "device_code=$DEVICE_CODE" \
    -d "grant_type=urn:ietf:params:oauth:grant-type:device_code")

  ACCESS_TOKEN=$(echo "$TOKEN_RESPONSE" | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)
  if [ -n "$ACCESS_TOKEN" ]; then
    break
  fi
  sleep 5
done

if [ -z "$ACCESS_TOKEN" ]; then
  echo "获取令牌失败"
  exit 1
fi

echo "Step 3: 创建 GitHub 仓库..."
curl -s -X POST https://api.github.com/user/repos \
  -H "Authorization: token $ACCESS_TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  -d "{\"name\":\"$REPO_NAME\",\"private\":false,\"auto_init\":true}" > /dev/null

echo "Step 4: 推送原型代码..."
cd "$PROTOTYPE_DIR"
git init 2>/dev/null || true
git config user.email "deploy@example.com"
git config user.name "Deploy Bot"
git remote remove origin 2>/dev/null || true
git remote add origin "https://$GITHUB_USER:$ACCESS_TOKEN@github.com/$GITHUB_USER/$REPO_NAME.git"
git add .
git commit -m "Initial prototype commit" || true
git push -f origin main

echo "Step 5: 开启 GitHub Pages..."
curl -s -X POST "https://api.github.com/repos/$GITHUB_USER/$REPO_NAME/pages" \
  -H "Authorization: token $ACCESS_TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  -d '{"source":{"branch":"main","path":"/"}}' > /dev/null

echo ""
echo "部署完成，访问链接："
echo "https://$GITHUB_USER.github.io/$REPO_NAME/"
